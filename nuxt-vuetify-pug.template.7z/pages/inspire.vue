<template lang="pug">
v-layout
    v-flex(text-xs-center)
      img.mb-5( src="/v.png" alt="Vuetify.js")
      blockquote.blockquote &#8220;First, solve the problem. Then, write the code.&#8221;
        footer
          small
            em &mdash;John Johnson

</template>
